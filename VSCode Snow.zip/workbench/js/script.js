const {
	E, LN10, LN2, LOG10E, LOG2E, PI, SQRT1_2, SQRT2,
	abs, acos, acosh, asin, asinh, atan, atan2, atanh, cbrt, ceil, clz32,
	cosh, exp, expm1, floor, fround, hypot, imul, log, log10, log1p, log2, max,
	min, pow, /* random, */ round, sign, sinh, sqrt, tan, tanh, trunc
} = Math;

const ease = {
	linearTween,
	easeInQuad, easeOutQuad, easeInOutQuad,
	easeInCubic, easeOutCubic, easeInOutCubic,
	easeInQuart, easeOutQuart, easeInOutQuart,
	easeInQuint, easeOutQuint, easeInOutQuint,
	easeInSine, easeOutSine, easeInOutSine,
	easeInExpo, easeOutExpo, easeInOutExpo,
	easeInCirc, easeOutCirc, easeInOutCirc,
	in: { linear: linearTween, quad: easeInQuad, cubic: easeInCubic, quart: easeInQuart, quint: easeInQuint, sine: easeInSine, expo: easeInExpo, circ: easeInCirc },
	out: { linear: linearTween, quad: easeOutQuad, cubic: easeOutCubic, quart: easeOutQuart, quint: easeOutQuint, sine: easeOutSine, expo: easeOutExpo, circ: easeOutCirc },
	inOut: { linear: linearTween, quad: easeInOutQuad, cubic: easeInOutCubic, quart: easeInOutQuart, quint: easeInOutQuint, sine: easeInOutSine, expo: easeInOutExpo, circ: easeInOutCirc },
	linear: Object.assign(linearTween,
		{ in: linearTween, out: linearTween, inOut: linearTween }),
	quad: { in: easeInQuad, out: easeOutQuad, inOut: easeInOutQuad },
	cubic: { in: easeInCubic, out: easeOutCubic, inOut: easeInOutCubic },
	quart: { in: easeInQuart, out: easeOutQuart, inOut: easeInOutQuart },
	quint: { in: easeInQuint, out: easeOutQuint, inOut: easeInOutQuint },
	sine: { in: easeInSine, out: easeOutSine, inOut: easeInOutSine },
	expo: { in: easeInExpo, out: easeOutExpo, inOut: easeInOutExpo },
	circ: { in: easeInCirc, out: easeOutCirc, inOut: easeInOutCirc }
};
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const SPRITE_SIZE = 32;

let flakes = [];
let spritesheet;
let SPRITE_SCALE = 1;
let MAX_FLAKES = 24; //雪花數量
let WIND_SCALE = 1;		//風大小
let WIND_DENSITY = 1;	//風密度
let GRAVITY = 1;	//重力

let GRAVITY_BASE = 1.5;
let GRAVITY_SPEED = 1.5;
let _anim, _lastCanvasTime, canvasFrameRate, frameCount, width, height, width_half, height_half, width_quarter, height_quarter;

const simplex = new SimplexNoise();


let _defaulCanvasOptions = {
	autoClear: true,
	autoCompensate: false,
	autoPushPop: true,
	canvas: true,
	desynchronized: false,
	width: null,
	height: null
};
let _canvasOptions = {};

let canvas = document.getElementById('canvas');//畫布
if (canvas === null) {
	canvas = document.createElement('canvas');
	canvas.id = 'canvas';
	document.body.appendChild(canvas);
}
let ctx = canvas.getContext('2d', {
	desynchronized: window.canvasOptions && window.canvasOptions.desynchronized !== undefined ?
		window.canvasOptions.desynchronized : _defaulCanvasOptions.desynchronized
	// preserveDrawingBuffer: true // WebGL
});
const _originalCtx = ctx;

//重新設置大小
window.addEventListener('resize', _resizeCanvas);

window.addEventListener('load', () => {
	mousePos = new Vector();
	mousePosPrev = new Vector();
	Object.assign(
		_canvasOptions,
		_defaulCanvasOptions,
		'canvasOptions' in window ? window.canvasOptions : {}
	);
	if (_canvasOptions.canvas === false) {
		document.body.removeChild(canvas);
	}
	_resizeCanvas();
	if ('setup' in window) {
		window.setup();
	}
	frameCount = 0;
	_anim = requestAnimationFrame(_draw);
});
function linearTween    /* simple linear tweening    */(t = 0.5, b = 0, c = 1, d = 1) { return c * t / d + b; }
function easeInQuad     /* quadratic   easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t + b; }
function easeOutQuad    /* quadratic   easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return -c * t * (t - 2) + b; }
function easeInOutQuad  /* quadratic   easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t + b; t--; return -c * 0.5 * (t * (t - 2) - 1) + b; }
function easeInCubic    /* cubic       easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t * t + b; }
function easeOutCubic   /* cubic       easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return c * (t * t * t + 1) + b; }
function easeInOutCubic /* cubic       easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t * t + b; t -= 2; return c * 0.5 * (t * t * t + 2) + b; }
function easeInQuart    /* quartic     easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t * t * t + b; }
function easeOutQuart   /* quartic     easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return -c * (t * t * t * t - 1) + b; }
function easeInOutQuart /* quartic     easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t * t * t + b; t -= 2; return -c * 0.5 * (t * t * t * t - 2) + b; }
function easeInQuint    /* quintic     easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t * t * t * t + b; }
function easeOutQuint   /* quintic     easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return c * (t * t * t * t * t + 1) + b; }
function easeInOutQuint /* quintic     easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t * t * t * t + b; t -= 2; return c * 0.5 * (t * t * t * t * t + 2) + b; }
function easeInSine     /* sinusoidal  easing in     */(t = 0.5, b = 0, c = 1, d = 1) { return -c * cos(t / d * HALF_PI) + c + b; }
function easeOutSine    /* sinusoidal  easing out    */(t = 0.5, b = 0, c = 1, d = 1) { return c * sin(t / d * HALF_PI) + b; }
function easeInOutSine  /* sinusoidal  easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { return -c * 0.5 * (cos(PI * t / d) - 1) + b; }
function easeInExpo     /* exponential easing in     */(t = 0.5, b = 0, c = 1, d = 1) { return c * pow(2, 10 * (t / d - 1)) + b; }
function easeOutExpo    /* exponential easing out    */(t = 0.5, b = 0, c = 1, d = 1) { return c * (-pow(2, -10 * t / d) + 1) + b; }
function easeInOutExpo  /* exponential easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * pow(2, 10 * (t - 1)) + b; t--; return c * 0.5 * (-pow(2, -10 * t) + 2) + b; }
function easeInCirc     /* circular    easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return -c * (sqrt(1 - t * t) - 1) + b; }
function easeOutCirc    /* circular    easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return c * sqrt(1 - t * t) + b; }
function easeInOutCirc  /* circular    easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return -c * 0.5 * (sqrt(1 - t * t) - 1) + b; t -= 2; return c * 0.5 * (sqrt(1 - t * t) + 1) + b; }
function random(low = 1, high = null) {
	if (Array.isArray(low)) {
		return low[floor(Math.random() * low.length)];
	}
	if (high === null) {
		return Math.random() * low;
	}
	return Math.random() * (high - low) + low;
}

function clear(x, y, w, h) {
	if (x !== undefined && typeof x === 'number') {
		ctx.clearRect(x, y, w, h);
	}
	else if (_canvasOptions.centered && _canvasCurrentlyCentered/*  && x !== null */) {
		ctx.clearRect(-width_half, -height_half, width, height);
	}
	else {
		ctx.clearRect(0, 0, width, height);
	}
}
function _resizeCanvas(specificCanvas) {
	width = canvas.width = _canvasOptions.width !== null ? _canvasOptions.width : window.innerWidth;
	height = canvas.height = _canvasOptions.height !== null ? _canvasOptions.height : window.innerHeight;
	width_quarter = (width_half = width * 0.5) * 0.5;
	height_quarter = (height_half = height * 0.5) * 0.5;
	if ('onResize' in window) {
		window.onResize();
	}
}

function push() {
	ctx.save();
}

function pop() {
	ctx.restore();
}
function loadImage(url) {
	return new Promise((resolve, reject) => {
		let img = new Image();
		img.crossOrigin = 'Anonymous';
		img.onload = () => resolve(img);
		img.src = url;
	});
}
function _draw(timestamp) {
	frameCount++;
	canvasFrameRate = 1000.0 / (timestamp - _lastCanvasTime);
	_lastCanvasTime = timestamp;
	ctx = _originalCtx;
	_canvasOptions.autoClear && clear(null);
	if (_canvasOptions.autoPushPop) {
		push();
		_canvasOptions.centered && (_canvasCurrentlyCentered = true) && translateCenter();
		_canvasOptions.autoCompensate && compensateCanvas();
	}
	'draw' in window && window.draw(timestamp);
	_canvasOptions.autoPushPop && pop();
	_canvasCurrentlyCentered = false;
	if (_canvasOptions.drawAndStop) {
		return;
	}
	_anim = requestAnimationFrame(_draw);
}

function beginPath() {
	ctx.beginPath();
}
function draw(e) {
	if (!spritesheet) {
		return;
	}
	const time = e * 0.001;
	const windTime = time * 0.1 * WIND_DENSITY;
	beginPath();
	for (let i = flakes.length - 1; i >= 0; i--) {
		const f = flakes[i];
		f.update(time, windTime);
		f.draw(time);
		if (
			GRAVITY >= 0 && f.pos.y > height + SPRITE_SIZE ||
			GRAVITY < 0 && f.pos.y < -SPRITE_SIZE) {
			// flakes.splice(i, 1);
			f.randomize();
		}
	}
	stroke(hsl(0, 0, 100, 0));
}

const sclRngs = [
	[0.12, 0.2], [0.25, 0.4], [0.5, 0.7], [0.8, 1]];


const scales = [
	sclRngs[0], sclRngs[0], sclRngs[0],
	sclRngs[1], sclRngs[1], sclRngs[1], sclRngs[1],
	sclRngs[2], sclRngs[2], sclRngs[2], sclRngs[2],
	sclRngs[3], sclRngs[3]];

function sin(input, mult = null) {
	let s = Math.sin(input % PI * 2);
	if (mult === null) {
		return s;
	}
	return s * mult;
}

function translate(x = 0, y = 0) {
	if (typeof x === 'number') {
		ctx.translate(x, y);
	}
	else if ('x' in x) {
		ctx.translate(x.x, x.y);
	}
}
function rotate(rot, offsetX, offsetY) {
	rot = rot % PI * 2;
	if (offsetX === undefined) {
		ctx.rotate(rot);
	}
	else if (typeof offsetX !== 'number') {
		if ('x' in offsetX) {
			ctx.translate(offsetX.x, offsetX.y);
			ctx.rotate(rot);
			ctx.translate(-offsetX.x, -offsetX.y);
		}
	}
	else {
		ctx.translate(offsetX, offsetY);
		ctx.rotate(rot);
		ctx.translate(-offsetX, -offsetY);
	}
}
function scale(x = 1, y = x) {
	ctx.scale(x, y);
}
//開始繪製
function drawImage(img, x = 0, y = 0, ...args) {
	ctx.drawImage(img, x, y, ...args);
}
function stroke(...args) {
	if (args.length) {
		strokeStyle(...args);
	}
	ctx.stroke();
}


function hsl(hue, sat, light, alpha = 1) {
	if (typeof hue !== 'number') {
		if (Array.isArray(hue)) {
			[hue, sat, light, alpha = alpha] = hue;
		}
		else if ('h' in hue) {
			({ h: hue, s: sat, l: light, a: alpha = alpha } = hue);
		}
	}
	hue = hue % 360;
	if (hue < 0) {
		hue += 360;
	}
	return `hsl(${hue} ${sat}% ${light}% / ${alpha})`;
}
function strokeStyle(...args) {
	if (args.length === 1) {
		let a = args[0];
		if (typeof a === 'string' || a instanceof CanvasGradient) {
			ctx.strokeStyle = a;
		}
	}
	else if (args.length === 2) {
		strokeStyle(args[0]);
		lineWidth(args[1]);
	}
	return ctx.strokeStyle;
}
function setup() {
	loadImage('img/sn.png').then(img => spritesheet = img);
	
	/*for (let i = 0; i < MAX_FLAKES; i++) {
		const snow = new Snowflake();
		snow._pos.setY(random(-SPRITE_SIZE, height));

		flakes.push(snow);
	}*/
	
	for(i=0;i<=MAX_FLAKES;++i){
		for(j=0;j<=MAX_FLAKES;++j){
			var tempi=i*(3.14159/MAX_FLAKES),tempj=j*(3.14159*2/MAX_FLAKES);
			var x0 = 1*Math.sin(tempi) * Math.cos(tempj);
			var y0 = 1*Math.sin(tempi) * Math.sin(tempj);
			var z0 = 1*Math.cos(tempi);
			var s = Math.sin(0);
			var c = Math.cos(0);
			var c1 = 1 - c;
			var u = 1 / Math.sqrt(3);
			var u2 = u * u;
			var x2 = (window.innerWidth/2)  + x0 * (c  + u2 * c1) 	 	+ 	y0 * (u2 * c1 - u  * s)  	+	z0 * (u2 * c1 + u * s);
			var y2 = (window.innerHeight/2) + x0 * (u2 * c1 + u   * s)	+ 	y0 * (c + u2 * c1)		 	+	z0 * (u2 * c1 - u * s);
			var z2 = x0 * (u2 * c1 - u * s)	+ y0 * (u2 * c1 + u   * s) 		+	z0 * (c + u2 * c1);
			
			const snow = new Snowflake(i,j);
			snow._pos.set(x2,y2,z2);
			flakes.push(snow);
			
			
		}
	}
}
//創建雪花
class Snowflake {
	constructor(i = 0, j = 0) {
		_defineProperty(this, "_pos", new Vector()); _defineProperty(this, "pos", new Vector());
		this.i2 = i;
		this.j2 = j;
		this.Rotation = 0;
		this.SnowScale = 0;
		this.SnowSwelled = 0;
		this.dead = 0;
		this.randomize();
	}
	randomize() {
		this._pos.set(random(-SPRITE_SIZE, width), -SPRITE_SIZE);
		this.scale = SPRITE_SCALE * random(...random(scales));
		this.img = [random([0, 1, 2, 3]), random([0, 1, 2, 3])];
		this.offset = random(10000000);
		this.rot = random(0.1, 1) * PI * random([-1, 1]);
	}
	update(e = performance.now(), windTime) {
		if (this.dead === 0){
		const { _pos, pos, scale, offset } = this;
		let wind = 0;
		if (WIND_SCALE) {
			wind = WIND_SCALE * simplex.noise3D(
				..._pos._.mult(WIND_DENSITY * 0.0002 * (1 - scale * 0.5)).xy,
				windTime);

		}
			if (this.SnowSwelled === 0) {
				for(i=0;i<=MAX_FLAKES;++i){
					for(j=0;j<=MAX_FLAKES;++j){
						if (i == this.i2 && j == this.j2){
							
							var tempi=i*(3.14159/MAX_FLAKES),tempj=j*(3.14159*2/MAX_FLAKES);
							var x0 = this.SnowScale*Math.sin(tempi) * Math.cos(tempj);
							var y0 = this.SnowScale*Math.sin(tempi) * Math.sin(tempj);
							var z0 = this.SnowScale*Math.cos(tempi);
							var s = Math.sin(this.Rotation);
							var c = Math.cos(this.Rotation);
							var c1 = 1 - c;
							var u = 1 / Math.sqrt(3);
							var u2 = u * u;
							var x2 = (window.innerWidth/2)  + x0 * (c  + u2 * c1) 	 	+ 	y0 * (u2 * c1 - u  * s)  	+	z0 * (u2 * c1 + u * s);
							var y2 = (window.innerHeight/2) + x0 * (u2 * c1 + u   * s)	+ 	y0 * (c + u2 * c1)		 	+	z0 * (u2 * c1 - u * s);
							var z2 = x0 * (u2 * c1 - u * s)	+ y0 * (u2 * c1 + u   * s) 		+	z0 * (c + u2 * c1);
							
							pos.set(x2,y2,z2);
							if(pos.x > window.innerWidth || pos.y > window.innerHeight){
								this.SnowSwelled = 1;
								pos.set(Math.random(window.innerWidth),Math.random(window.innerHeight),0);
								if (Math.random()*100 > 17){
									this.dead = 1;
								}
								console.log((Math.random(100) > 1));
							}
						}
					}
				}
				this.Rotation += 0.01;
				this.SnowScale += 2;
			}else{
				_pos.add(wind, ease.expo.inOut(scale, GRAVITY_BASE, GRAVITY_SPEED, 1));
		
				pos.set(_pos).add(sin(offset + e * scale) * (scale + 1) * 10, 0);
			}
		}

	}
	draw(e = performance.now()) {
		if (this.dead === 0){
			const { pos, vel, scale: flakeScale, img, offset, rot } = this;
			const size = SPRITE_SIZE * flakeScale;
			push();
			translate(pos);
			rotate(offset * flakeScale + rot * e);
			const r = 0;
			rotate(r);
			scale(sin((e + offset) * rot), 1);
			rotate(-r);
			drawImage(
				spritesheet,
				img[0] * SPRITE_SIZE, img[1] * SPRITE_SIZE,
				SPRITE_SIZE, SPRITE_SIZE,
				-size * 0.5, -size * 0.5,
				size, size);

			pop();
		}
	}
}

function createVector(x, y, z) {
	return new Vector(x, y, z);
}
class Vector {
	constructor(x = 0, y = 0, z = 0) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	toString() {
		let { x, y, z } = this;
		return `{ x: ${x}, y: ${y}, z: ${z} }`;
	}
	get xy() { return [this.x, this.y]; }
	get xyz() { return [this.x, this.y, this.z]; }
	copy() {
		return createVector(this.x, this.y, this.z);
	}
	get _() {
		return this.copy();
	}
	set(x = this.x, y = this.y, z = this.z) {
		if (x instanceof Vector) {
			this.x = x.x;
			this.y = x.y;
			this.z = x.z;
			return this;
		}
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	setX(x = this.x) {
		if (x instanceof Vector) {
			this.x = x.x;
			return this;
		}
		this.x = x;
		return this;
	}
	setY(y = this.y) {
		if (y instanceof Vector) {
			this.y = y.y;
			return this;
		}
		this.y = y;
		return this;
	}
	setZ(z = this.z) {
		if (z instanceof Vector) {
			this.z = z.z;
			return this;
		}
		this.z = z;
		return this;
	}
	mult(x = 1, y = x, z = x) {
		if (x instanceof Vector) {
			this.x *= x.x;
			this.y *= x.y;
			this.z *= x.z;
			return this;
		}
		this.x *= x;
		this.y *= y;
		this.z *= z;
		return this;
	}
	add(x = 0, y = undefined, z = undefined) {
		if (y === undefined) {
			y = x;
			z = x;
		}
		else if (z === undefined) {
			z = 0;
		}
		if (x instanceof Vector) {
			this.x += x.x;
			this.y += x.y;
			this.z += x.z;
			return this;
		}
		this.x += x;
		this.y += y;
		this.z += z;
		return this;
	}
}