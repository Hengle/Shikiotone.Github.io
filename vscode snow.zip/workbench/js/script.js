const {
	E, LN10, LN2, LOG10E, LOG2E, PI, SQRT1_2, SQRT2,
	abs, acos, acosh, asin, asinh, atan, atan2, atanh, cbrt, ceil, clz32,
	cosh, exp, expm1, floor, fround, hypot, imul, log, log10, log1p, log2, max,
	min, pow, /* random, */ round, sign, sinh, sqrt, tan, tanh, trunc
} = Math;

const ease = {
	linearTween,
	easeInQuad, easeOutQuad, easeInOutQuad,
	easeInCubic, easeOutCubic, easeInOutCubic,
	easeInQuart, easeOutQuart, easeInOutQuart,
	easeInQuint, easeOutQuint, easeInOutQuint,
	easeInSine, easeOutSine, easeInOutSine,
	easeInExpo, easeOutExpo, easeInOutExpo,
	easeInCirc, easeOutCirc, easeInOutCirc,
	in: { linear: linearTween, quad: easeInQuad, cubic: easeInCubic, quart: easeInQuart, quint: easeInQuint, sine: easeInSine, expo: easeInExpo, circ: easeInCirc },
	out: { linear: linearTween, quad: easeOutQuad, cubic: easeOutCubic, quart: easeOutQuart, quint: easeOutQuint, sine: easeOutSine, expo: easeOutExpo, circ: easeOutCirc },
	inOut: { linear: linearTween, quad: easeInOutQuad, cubic: easeInOutCubic, quart: easeInOutQuart, quint: easeInOutQuint, sine: easeInOutSine, expo: easeInOutExpo, circ: easeInOutCirc },
	linear: Object.assign(linearTween,
		{ in: linearTween, out: linearTween, inOut: linearTween }),
	quad: { in: easeInQuad, out: easeOutQuad, inOut: easeInOutQuad },
	cubic: { in: easeInCubic, out: easeOutCubic, inOut: easeInOutCubic },
	quart: { in: easeInQuart, out: easeOutQuart, inOut: easeInOutQuart },
	quint: { in: easeInQuint, out: easeOutQuint, inOut: easeInOutQuint },
	sine: { in: easeInSine, out: easeOutSine, inOut: easeInOutSine },
	expo: { in: easeInExpo, out: easeOutExpo, inOut: easeInOutExpo },
	circ: { in: easeInCirc, out: easeOutCirc, inOut: easeInOutCirc }
};
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const SPRITE_SIZE = 32;

let flakes = [];
let spritesheet;
let SPRITE_SCALE = 1;
let MAX_FLAKES = 100; //雪花數量
let WIND_SCALE = 1;
let WIND_DENSITY = 1;
let GRAVITY = 0.5;	//重力

let GRAVITY_BASE = 1.5;
let GRAVITY_SPEED = 1.5;
let _anim, _lastCanvasTime, canvasFrameRate, frameCount, width, height, width_half, height_half, width_quarter, height_quarter;

const simplex = new SimplexNoise();


let _defaulCanvasOptions = {
	autoClear: true,
	autoCompensate: false,
	autoPushPop: true,
	canvas: true,
	desynchronized: false,
	width: null,
	height: null
};
let _canvasOptions = {};

let canvas = document.getElementById('canvas');//畫布
if (canvas === null) {
	canvas = document.createElement('canvas');
	canvas.id = 'canvas';
	document.body.appendChild(canvas);
}
let ctx = canvas.getContext('2d', {
	desynchronized: window.canvasOptions && window.canvasOptions.desynchronized !== undefined ?
		window.canvasOptions.desynchronized : _defaulCanvasOptions.desynchronized
	// preserveDrawingBuffer: true // WebGL
});
const _originalCtx = ctx;

//重新設置大小
window.addEventListener('resize', _resizeCanvas);

window.addEventListener('load', () => {
	mousePos = new Vector();
	mousePosPrev = new Vector();
	Object.assign(
		_canvasOptions,
		_defaulCanvasOptions,
		'canvasOptions' in window ? window.canvasOptions : {}
	);
	if (_canvasOptions.canvas === false) {
		document.body.removeChild(canvas);
	}
	_resizeCanvas();
	if ('setup' in window) {
		window.setup();
	}
	frameCount = 0;
	_anim = requestAnimationFrame(_draw);
});
function setup() {
	loadImage('img/sn.png').then(img => spritesheet = img);

	// ?sprite_scale=1.0&max_flakes=100&wind_scale=1&wind_density=1

	for (let i = 0; i < MAX_FLAKES; i++) {
		const snow = new Snowflake();
		snow._pos.setY(random(-SPRITE_SIZE, height));

		flakes.push(snow);
	}
}
function linearTween    /* simple linear tweening    */(t = 0.5, b = 0, c = 1, d = 1) { return c * t / d + b; }
function easeInQuad     /* quadratic   easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t + b; }
function easeOutQuad    /* quadratic   easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return -c * t * (t - 2) + b; }
function easeInOutQuad  /* quadratic   easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t + b; t--; return -c * 0.5 * (t * (t - 2) - 1) + b; }
function easeInCubic    /* cubic       easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t * t + b; }
function easeOutCubic   /* cubic       easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return c * (t * t * t + 1) + b; }
function easeInOutCubic /* cubic       easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t * t + b; t -= 2; return c * 0.5 * (t * t * t + 2) + b; }
function easeInQuart    /* quartic     easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t * t * t + b; }
function easeOutQuart   /* quartic     easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return -c * (t * t * t * t - 1) + b; }
function easeInOutQuart /* quartic     easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t * t * t + b; t -= 2; return -c * 0.5 * (t * t * t * t - 2) + b; }
function easeInQuint    /* quintic     easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return c * t * t * t * t * t + b; }
function easeOutQuint   /* quintic     easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return c * (t * t * t * t * t + 1) + b; }
function easeInOutQuint /* quintic     easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * t * t * t * t * t + b; t -= 2; return c * 0.5 * (t * t * t * t * t + 2) + b; }
function easeInSine     /* sinusoidal  easing in     */(t = 0.5, b = 0, c = 1, d = 1) { return -c * cos(t / d * HALF_PI) + c + b; }
function easeOutSine    /* sinusoidal  easing out    */(t = 0.5, b = 0, c = 1, d = 1) { return c * sin(t / d * HALF_PI) + b; }
function easeInOutSine  /* sinusoidal  easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { return -c * 0.5 * (cos(PI * t / d) - 1) + b; }
function easeInExpo     /* exponential easing in     */(t = 0.5, b = 0, c = 1, d = 1) { return c * pow(2, 10 * (t / d - 1)) + b; }
function easeOutExpo    /* exponential easing out    */(t = 0.5, b = 0, c = 1, d = 1) { return c * (-pow(2, -10 * t / d) + 1) + b; }
function easeInOutExpo  /* exponential easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return c * 0.5 * pow(2, 10 * (t - 1)) + b; t--; return c * 0.5 * (-pow(2, -10 * t) + 2) + b; }
function easeInCirc     /* circular    easing in     */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; return -c * (sqrt(1 - t * t) - 1) + b; }
function easeOutCirc    /* circular    easing out    */(t = 0.5, b = 0, c = 1, d = 1) { t /= d; t--; return c * sqrt(1 - t * t) + b; }
function easeInOutCirc  /* circular    easing in/out */(t = 0.5, b = 0, c = 1, d = 1) { t /= d * 0.5; if (t < 1) return -c * 0.5 * (sqrt(1 - t * t) - 1) + b; t -= 2; return c * 0.5 * (sqrt(1 - t * t) + 1) + b; }
function random(low = 1, high = null) {
	if (Array.isArray(low)) {
		return low[floor(Math.random() * low.length)];
	}
	if (high === null) {
		return Math.random() * low;
	}
	return Math.random() * (high - low) + low;
}

function clear(x, y, w, h) {
	if (x !== undefined && typeof x === 'number') {
		ctx.clearRect(x, y, w, h);
	}
	else if (_canvasOptions.centered && _canvasCurrentlyCentered/*  && x !== null */) {
		ctx.clearRect(-width_half, -height_half, width, height);
	}
	else {
		ctx.clearRect(0, 0, width, height);
	}
}
function _resizeCanvas(specificCanvas) {
	width = canvas.width = _canvasOptions.width !== null ? _canvasOptions.width : window.innerWidth;
	height = canvas.height = _canvasOptions.height !== null ? _canvasOptions.height : window.innerHeight;
	width_quarter = (width_half = width * 0.5) * 0.5;
	height_quarter = (height_half = height * 0.5) * 0.5;
	if ('onResize' in window) {
		window.onResize();
	}
}

function push() {
	ctx.save();
}

function pop() {
	ctx.restore();
}
function loadImage(url) {
	return new Promise((resolve, reject) => {
		let img = new Image();
		img.crossOrigin = 'Anonymous';
		img.onload = () => resolve(img);
		img.src = url;
	});
}
function _draw(timestamp) {
	frameCount++;
	canvasFrameRate = 1000.0 / (timestamp - _lastCanvasTime);
	_lastCanvasTime = timestamp;
	ctx = _originalCtx;
	_canvasOptions.autoClear && clear(null);
	if (_canvasOptions.autoPushPop) {
		push();
		_canvasOptions.centered && (_canvasCurrentlyCentered = true) && translateCenter();
		_canvasOptions.autoCompensate && compensateCanvas();
	}
	'draw' in window && window.draw(timestamp);
	_canvasOptions.autoPushPop && pop();
	_canvasCurrentlyCentered = false;
	if (_canvasOptions.drawAndStop) {
		return;
	}
	_anim = requestAnimationFrame(_draw);
}

function beginPath() {
	ctx.beginPath();
}
function draw(e) {
	if (!spritesheet) {
		return;
	}
	const time = e * 0.001;
	const windTime = time * 0.1 * WIND_DENSITY;
	beginPath();
	for (let i = flakes.length - 1; i >= 0; i--) {
		const f = flakes[i];
		f.update(time, windTime);
		f.draw(time);
		if (
			GRAVITY >= 0 && f.pos.y > height + SPRITE_SIZE ||
			GRAVITY < 0 && f.pos.y < -SPRITE_SIZE) {
			// flakes.splice(i, 1);
			f.randomize();
		}
	}
	stroke(hsl(0, 0, 100, 0));
}

const sclRngs = [
	[0.12, 0.2], [0.25, 0.4], [0.5, 0.7], [0.8, 1]];


const scales = [
	sclRngs[0], sclRngs[0], sclRngs[0],
	sclRngs[1], sclRngs[1], sclRngs[1], sclRngs[1],
	sclRngs[2], sclRngs[2], sclRngs[2], sclRngs[2],
	sclRngs[3], sclRngs[3]];

function sin(input, mult = null) {
	let s = Math.sin(input % PI * 2);
	if (mult === null) {
		return s;
	}
	return s * mult;
}

function translate(x = 0, y = 0) {
	if (typeof x === 'number') {
		ctx.translate(x, y);
	}
	else if ('x' in x) {
		ctx.translate(x.x, x.y);
	}
}
function rotate(rot, offsetX, offsetY) {
	rot = rot % PI * 2;
	if (offsetX === undefined) {
		ctx.rotate(rot);
	}
	else if (typeof offsetX !== 'number') {
		if ('x' in offsetX) {
			ctx.translate(offsetX.x, offsetX.y);
			ctx.rotate(rot);
			ctx.translate(-offsetX.x, -offsetX.y);
		}
	}
	else {
		ctx.translate(offsetX, offsetY);
		ctx.rotate(rot);
		ctx.translate(-offsetX, -offsetY);
	}
}
function scale(x = 1, y = x) {
	ctx.scale(x, y);
}
//開始繪製
function drawImage(img, x = 0, y = 0, ...args) {
	ctx.drawImage(img, x, y, ...args);
}
function stroke(...args) {
	if (args.length) {
		strokeStyle(...args);
	}
	ctx.stroke();
}


function hsl(hue, sat, light, alpha = 1) {
	if (typeof hue !== 'number') {
		if (Array.isArray(hue)) {
			[hue, sat, light, alpha = alpha] = hue;
		}
		else if ('h' in hue) {
			({ h: hue, s: sat, l: light, a: alpha = alpha } = hue);
		}
	}
	hue = hue % 360;
	if (hue < 0) {
		hue += 360;
	}
	return `hsl(${hue} ${sat}% ${light}% / ${alpha})`;
}
function strokeStyle(...args) {
	if (args.length === 1) {
		let a = args[0];
		if (typeof a === 'string' || a instanceof CanvasGradient) {
			ctx.strokeStyle = a;
		}
	}
	else if (args.length === 2) {
		strokeStyle(args[0]);
		lineWidth(args[1]);
	}
	return ctx.strokeStyle;
}

//創建雪花
class Snowflake {
	// scale; img; offset; rot;
	constructor() {
		_defineProperty(this, "_pos", new Vector()); _defineProperty(this, "pos", new Vector());
		this.randomize();
	}
	randomize() {
		this._pos.set(random(-SPRITE_SIZE, width), -SPRITE_SIZE);
		this.scale = SPRITE_SCALE * random(...random(scales));
		this.img = [random([0, 1, 2, 3]), random([0, 1, 2, 3])];
		this.offset = random(10000000);
		this.rot = random(0.1, 1) * PI * random([-1, 1]);
	}
	update(e = performance.now(), windTime) {
		const { _pos, pos, scale, offset } = this;
		let wind = 0;
		if (WIND_SCALE) {
			wind = WIND_SCALE * simplex.noise3D(
				..._pos._.mult(WIND_DENSITY * 0.0002 * (1 - scale * 0.5)).xy,
				windTime);

		}
		_pos.add(
			wind,
			ease.expo.inOut(scale, GRAVITY_BASE, GRAVITY_SPEED, 1));

		pos.set(_pos).
			add(
				sin(offset + e * scale) * (scale + 1) * 10,
				0);

	}
	draw(e = performance.now()) {
		const { pos, vel, scale: flakeScale, img, offset, rot } = this;
		const size = SPRITE_SIZE * flakeScale;
		push();
		translate(pos);
		rotate(offset * flakeScale + rot * e);
		const r = 0;
		rotate(r);
		scale(sin((e + offset) * rot), 1);
		rotate(-r);
		drawImage(
			spritesheet,
			img[0] * SPRITE_SIZE, img[1] * SPRITE_SIZE,
			SPRITE_SIZE, SPRITE_SIZE,
			-size * 0.5, -size * 0.5,
			size, size);

		pop();
	}
}

function createVector(x, y, z) {
	return new Vector(x, y, z);
}
class Vector {
	constructor(x = 0, y = 0, z = 0) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	toString() {
		let { x, y, z } = this;
		return `{ x: ${x}, y: ${y}, z: ${z} }`;
	}

	static center() {
		return createVector(width_half, height_half);
	}

	static from(v, ...args) {
		if (v === undefined) {
			return createVector();
		}
		else if (Array.isArray(v)) {
			return createVector(...v);
		}
		else if (typeof v === 'object') {
			return createVector(v.x, v.y, v.z);
		}
		else if (typeof v === 'number') {
			return createVector(v, ...args);
		}
	}

	static fromAngle(angle, mult = 1) {
		let v = createVector(cos(angle), sin(angle));
		if (mult !== 1) v.mult(mult);
		return v;
	}

	static random2D(angle = true, mult = 1) {
		let v;
		if (angle === true) {
			v = Vector.fromAngle(random(PI * 2));
		}
		else {
			v = createVector(random(-1, 1), random(-1, 1));
		}
		if (typeof angle === 'number') {
			v.mult(angle);
		}
		else if (mult !== 1) {
			v.mult(mult);
		}
		return v;
	}

	static lerp(start, stop, amt = 0.5, apply = false) {
		let x = start.x === stop.x ? start.x : lerp(start.x, stop.x, amt);
		let y = start.y === stop.y ? start.y : lerp(start.y, stop.y, amt);
		let z = start.z === undefined ? stop.z === undefined ? 0 : stop.z : start.z === stop.z ? start.z : lerp(start.z, stop.z, amt);
		if (apply) {
			return start.set(x, y, z);
		}
		return createVector(x, y, z);
	}

	get xy() { return [this.x, this.y]; }
	get yx() { return [this.y, this.x]; }
	get xz() { return [this.x, this.z]; }
	get zx() { return [this.z, this.x]; }
	get yz() { return [this.y, this.z]; }
	get zy() { return [this.z, this.y]; }
	get xyz() { return [this.x, this.y, this.z]; }
	get xzy() { return [this.x, this.z, this.y]; }
	get yxz() { return [this.y, this.x, this.z]; }
	get yzx() { return [this.y, this.z, this.x]; }
	get zyx() { return [this.z, this.y, this.x]; }
	get zxy() { return [this.z, this.x, this.y]; }

	get xyObject() { return { x: this.x, y: this.y }; }
	get xzObject() { return { x: this.x, z: this.z }; }
	get yzObject() { return { y: this.y, z: this.z }; }
	get xyzObject() { return { x: this.x, y: this.y, z: this.z }; }

	copy() {
		return createVector(this.x, this.y, this.z);
	}

	get _() {
		return this.copy();
	}

	equals(vec) {
		return this.x === vec.x && this.y === vec.y;
	}

	equals3D(vec = {}) {
		return this.x === vec.x && this.y === vec.y && this.z === vec.z;
	}

	draw() {
		point(this.x, this.y);
	}

	set(x = this.x, y = this.y, z = this.z) {
		if (x instanceof Vector) {
			this.x = x.x;
			this.y = x.y;
			this.z = x.z;
			return this;
		}
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	setX(x = this.x) {
		if (x instanceof Vector) {
			this.x = x.x;
			return this;
		}
		this.x = x;
		return this;
	}
	setY(y = this.y) {
		if (y instanceof Vector) {
			this.y = y.y;
			return this;
		}
		this.y = y;
		return this;
	}
	setZ(z = this.z) {
		if (z instanceof Vector) {
			this.z = z.z;
			return this;
		}
		this.z = z;
		return this;
	}
	setXY(x = this.x, y = this.y) {
		if (x instanceof Vector) {
			this.x = x.x;
			this.y = x.y;
			return this;
		}
		this.x = x;
		this.y = y;
		return this;
	}
	setYZ(y = this.y, z = this.z) {
		if (y instanceof Vector) {
			this.y = y.y;
			this.z = y.z;
			return this;
		}
		this.y = y;
		this.z = z;
		return this;
	}
	setXZ(x = this.x, z = this.y) {
		if (x instanceof Vector) {
			this.x = x.x;
			this.z = x.z;
			return this;
		}
		this.x = x;
		this.z = z;
		return this;
	}
	setZX(...args) {
		return this.setXZ(...args);
	}

	add(x = 0, y = undefined, z = undefined) {
		if (y === undefined) {
			y = x;
			z = x;
		}
		else if (z === undefined) {
			z = 0;
		}
		if (x instanceof Vector) {
			this.x += x.x;
			this.y += x.y;
			this.z += x.z;
			return this;
		}
		this.x += x;
		this.y += y;
		this.z += z;
		return this;
	}
	addX(n = 0) {
		if (n instanceof Vector) {
			this.x += n.x;
			return this;
		}
		this.x += n;
		return this;
	}
	addY(n = 0) {
		if (n instanceof Vector) {
			this.y += n.y;
			return this;
		}
		this.y += n;
		return this;
	}
	addZ(n = 0) {
		if (n instanceof Vector) {
			this.z += n.z;
			return this;
		}
		this.z += n;
		return this;
	}
	sub(x = 0, y = undefined, z = undefined) {
		if (y === undefined) {
			y = x;
			z = x;
		}
		else if (z === undefined) {
			z = 0;
		}
		if (x instanceof Vector) {
			this.x -= x.x;
			this.y -= x.y;
			this.z -= x.z;
			return this;
		}
		this.x -= x;
		this.y -= y;
		this.z -= z;
		return this;
	}
	subX(n = 0) {
		if (n instanceof Vector) {
			this.x -= n.x;
			return this;
		}
		this.x -= n;
		return this;
	}
	subY(n = 0) {
		if (n instanceof Vector) {
			this.y -= n.y;
			return this;
		}
		this.y -= n;
		return this;
	}
	subZ(n = 0) {
		if (n instanceof Vector) {
			this.z -= n.z;
			return this;
		}
		this.z -= n;
		return this;
	}
	mult(x = 1, y = x, z = x) {
		if (x instanceof Vector) {
			this.x *= x.x;
			this.y *= x.y;
			this.z *= x.z;
			return this;
		}
		this.x *= x;
		this.y *= y;
		this.z *= z;
		return this;
	}
	multX(n = 1) {
		if (n instanceof Vector) {
			this.x *= n.x;
			return this;
		}
		this.x *= n;
		return this;
	}
	multY(n = 1) {
		if (n instanceof Vector) {
			this.y *= n.y;
			return this;
		}
		this.y *= n;
		return this;
	}
	multZ(n = 1) {
		if (n instanceof Vector) {
			this.z *= n.z;
			return this;
		}
		this.z *= n;
		return this;
	}
	div(x = 1, y = x, z = x) {
		if (x instanceof Vector) {
			this.x /= x.x;
			this.y /= x.y;
			this.z /= x.z;
			return this;
		}
		this.x /= x;
		this.y /= y;
		this.z /= z;
		return this;
	}
	divX(n = 1) {
		if (n instanceof Vector) {
			this.x /= n.x;
			return this;
		}
		this.x /= n;
		return this;
	}
	divY(n = 1) {
		if (n instanceof Vector) {
			this.y /= n.y;
			return this;
		}
		this.y /= n;
		return this;
	}
	divZ(n = 1) {
		if (n instanceof Vector) {
			this.z /= n.z;
			return this;
		}
		this.z /= n;
		return this;
	}

	mod(x, y, z) {
		if (x === undefined) return this;
		else if (x instanceof Vector) {
			this.x %= x.x;
			this.y %= x.y;
			this.z %= x.z;
			return this;
		}
		this.x %= x;
		this.y %= y === undefined ? x : y;
		this.z %= z === undefined ? x : y;
		return this;
	}
	// TODO: modX, modY, modZ

	min(mX = this.x, mY = this.y, mZ = this.z) {
		if (mX instanceof Vector) {
			this.x = min(this.x, mX.x);
			this.y = min(this.y, mX.y);
			this.z = min(this.z, mX.z);
			return this;
		}
		this.x = min(this.x, mX);
		this.y = min(this.y, mY);
		this.z = min(this.z, mZ);
		return this;
	}
	max(mX = this.x, mY = this.y, mZ = this.z) {
		if (mX instanceof Vector) {
			this.x = max(this.x, mX.x);
			this.y = max(this.y, mX.y);
			this.z = max(this.z, mX.z);
			return this;
		}
		this.x = max(this.x, mX);
		this.y = max(this.y, mY);
		this.z = max(this.z, mZ);
		return this;
	}
	minX(n) {
		this.x = min(this.x, n instanceof Vector ? n.x : n);
		return this;
	}
	minY(n) {
		this.y = min(this.y, n instanceof Vector ? n.y : n);
		return this;
	}
	minZ(n) {
		this.z = min(this.z, n instanceof Vector ? n.z : n);
		return this;
	}
	maxX(n) {
		this.x = max(this.x, n instanceof Vector ? n.x : n);
		return this;
	}
	maxY(n) {
		this.y = max(this.y, n instanceof Vector ? n.y : n);
		return this;
	}
	maxZ(n) {
		this.z = max(this.z, n instanceof Vector ? n.z : n);
		return this;
	}

	heading() {
		return atan2(this.y, this.x);
	}
	rotate(a = 0) {
		// if(a === 0) {
		// 	return this;
		// }
		// let newHeading = this.heading() + a;
		// let mag = this.mag();
		// return this.set(cos(newHeading), sin(newHeading)).mult(mag);
		if (!a) {
			return this;
		}
		const c = cos(a);
		const s = sin(a);
		const { x, y } = this;
		this.x = x * c - y * s;
		this.y = x * s + y * c;
		return this;
	}
	rotateXY(a) {
		let v = new Vector(this.x, this.y).rotate(a);
		this.x = v.x;
		this.y = v.y;
		return this;
	}
	rotateYZ(a) {
		let v = new Vector(this.y, this.z).rotate(a);
		this.y = v.x;
		this.z = v.y;
		return this;
	}
	rotateZX(a) {
		let v = new Vector(this.z, this.x).rotate(a);
		this.z = v.x;
		this.x = v.y;
		return this;
	}
	magSq() {
		return this.x * this.x + this.y * this.y;
	}
	magSq3D() {
		return this.x * this.x + this.y * this.y + this.z * this.z;
	}
	mag() {
		return Math.sqrt(this.magSq());
		// return hypot(this.x, this.y);
	}
	mag3D() {
		return Math.sqrt(this.magSq3D());
		// return hypot(this.x, this.y);
	}
	normalize(mag = this.mag()) {
		return mag === 0 ? this : this.div(mag);
	}
	normalize3D(mag = this.mag3D()) {
		return mag === 0 ? this : this.div(mag);
	}
	setMag(mag) {
		return this.normalize().mult(mag);
	}
	setMag3D(mag) {
		return this.normalize3D().mult(mag);
	}
	limit(max) {
		const magSq = this.magSq();
		if (magSq > max * max) {
			this.div(sqrt(magSq));
			this.mult(max);
		}
		return this;
	}
	limit3D(max) {
		const magSq = this.magSq3D();
		if (magSq > max * max) {
			this.div(sqrt(magSq));
			this.mult(max);
		}
		return this;
	}
	dot(x = 0, y = 0) {
		if (x instanceof Vector) {
			return this.dot(x.x, x.y);
		}
		return this.x * x + this.y * y;
	}
	dot3D(x = 0, y = 0, z = 0) {
		if (x instanceof Vector) {
			return this.dot(x.x, x.y, x.z);
		}
		return this.x * x + this.y * y + this.z * z;
	}
	dist(x, y) {
		if (x instanceof Vector) {
			return x.copy().sub(this).mag();
		}
		else if (typeof x === 'object' && 'x' in x) {
			({ x, y } = x);
		}
		return dist(this.x, this.y, x, y);
	}
	dist3D(v) {
		return v.copy().sub(this).mag3D();
	}
	lerp(stop, amt) {
		return Vector.lerp(this, stop, amt, true);
	}
	round() {
		this.x = round(this.x);
		this.y = round(this.y);
		this.z = round(this.z);
		return this;
	}
	floor() {
		this.x = floor(this.x);
		this.y = floor(this.y);
		this.z = floor(this.z);
		return this;
	}
	fastFloor() {
		this.x = ~~this.x;
		this.y = ~~this.y;
		this.z = ~~this.z;
		return this;
	}
	ceil() {
		this.x = ceil(this.x);
		this.y = ceil(this.y);
		this.z = ceil(this.z);
		return this;
	}
}